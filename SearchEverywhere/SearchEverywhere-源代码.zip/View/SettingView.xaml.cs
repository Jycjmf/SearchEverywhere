﻿using System.Windows.Controls;

namespace SearchEverywhere.View;

/// <summary>
///     Interaction logic for SettingView.xaml
/// </summary>
public partial class SettingView : UserControl
{
    public SettingView()
    {
        InitializeComponent();
    }
}