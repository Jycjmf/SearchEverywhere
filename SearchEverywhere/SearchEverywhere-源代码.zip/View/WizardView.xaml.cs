﻿using System.Windows.Controls;

namespace SearchEverywhere.View;

/// <summary>
///     Interaction logic for WizardView.xaml
/// </summary>
public partial class WizardView : UserControl
{
    public WizardView()
    {
        InitializeComponent();
    }
}